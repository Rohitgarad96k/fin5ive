import React from 'react';
import { Building2, Globe, TrendingUp, Briefcase, Plane, Factory, ShieldCheck, Landmark } from 'lucide-react';

const servicesData = [
  {
    title: "GIFT City IFSC Setup",
    description: "End-to-end registration, regulatory support, and compliance for your global financial expansion.",
    icon: <Globe className="w-8 h-8 text-finOrange" />,
  },
  {
    title: "Export Trade Finance",
    description: "Collateral-free working capital up to $2.5 Million. Financing invoices in less than 24 hours.",
    icon: <Plane className="w-8 h-8 text-finOrange" />,
  },
  {
    title: "MSME & Machinery Funding",
    description: "Up to 100% financing for machinery, working capital, and factory loans with flexible repayment.",
    icon: <Factory className="w-8 h-8 text-finOrange" />,
  },
  {
    title: "IPO Services",
    description: "Seamless transition from private to public on NSE Emerge or BSE SME with full SEBI compliance.",
    icon: <TrendingUp className="w-8 h-8 text-finOrange" />,
  },
  {
    title: "NRI Solutions",
    description: "Comprehensive tax planning, real estate advisory, and customized investment strategies for NRIs.",
    icon: <Briefcase className="w-8 h-8 text-finOrange" />,
  },
  {
    title: "ZED Gold Certification",
    description: "Hands-on implementation partner to achieve Zero Defect Zero Effect certification for MSMEs.",
    icon: <ShieldCheck className="w-8 h-8 text-finOrange" />,
  },
  {
    title: "Investment Portfolio",
    description: "Mutual Funds, PMS, AIF, and tailored asset management for High Net-Worth Individuals.",
    icon: <Building2 className="w-8 h-8 text-finOrange" />,
  },
  {
    title: "Working Capital Solutions",
    description: "Cash Credit (CC) and Overdraft facilities up to 25 Crore for seamless business operations.",
    icon: <Landmark className="w-8 h-8 text-finOrange" />,
  },
];

const ServicesGrid = () => {
  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl font-extrabold text-finBlue sm:text-4xl">
            Comprehensive Financial Solutions
          </h2>
          <p className="mt-4 max-w-2xl mx-auto text-xl text-gray-500">
            From capital acquisition to strict regulatory compliance, all under one roof.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {servicesData.map((service, index) => (
            <div 
              key={index} 
              className="bg-slate-50 border border-gray-100 rounded-xl p-8 hover:shadow-xl hover:border-finBlue/20 transition-all duration-300 group"
            >
              <div className="bg-white w-16 h-16 rounded-lg shadow-sm flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300">
                {service.icon}
              </div>
              <h3 className="text-xl font-bold text-finBlue mb-3">{service.title}</h3>
              <p className="text-gray-600 leading-relaxed mb-6 text-sm">
                {service.description}
              </p>
              <a href="#" className="text-finOrange font-semibold text-sm flex items-center hover:text-finOrange-dark">
                Learn more <span className="ml-1 opacity-0 group-hover:opacity-100 transition-opacity duration-300">→</span>
              </a>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ServicesGrid;