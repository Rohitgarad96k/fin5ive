import React, { useState } from 'react';
import { 
  TrendingUp, Award, ShieldCheck, Globe, Users, Target, 
  Briefcase, Building2, CheckCircle, ArrowRight, Linkedin, Mail, 
  Compass, Zap, Scale, X, Send, Calendar
} from 'lucide-react';

const About = () => {
  // --- STATE MANAGEMENT ---
  const [activeTab, setActiveTab] = useState('MISSION');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedLeader, setSelectedLeader] = useState('General'); // To track who they want to contact

  const handleOpenModal = (leader) => {
    setSelectedLeader(leader);
    setIsModalOpen(true);
  };

  // --- DATA ARRAYS ---
  const philosophy = {
    MISSION: {
      title: "Our Mission",
      icon: <Target className="w-8 h-8 text-finOrange" />,
      desc: "To democratize elite corporate finance and wealth management. We aim to bridge the gap between ambitious Indian businesses and global capital by providing flawless execution and unbiased advisory.",
      points: ["Unlocking MSME potential", "Navigating complex capital markets", "Securing generational wealth"]
    },
    VISION: {
      title: "Our Vision",
      icon: <Compass className="w-8 h-8 text-finOrange" />,
      desc: "To be India's most trusted, execution-driven financial advisory firm—recognized globally for transforming private ambitions into public success and establishing seamless cross-border wealth corridors.",
      points: ["Leading GIFT City expansion", "Setting the gold standard in IPOs", "Pioneering NRI financial solutions"]
    },
    DNA: {
      title: "Our DNA",
      icon: <Zap className="w-8 h-8 text-finOrange" />,
      desc: "We are not just paper-pushers or theoretical consultants. We are execution partners. If we architect a financial strategy, we stand by your side until the funds hit your account or the bell rings on the exchange.",
      points: ["Execution over advisory", "Uncompromising integrity", "Relentless pursuit of excellence"]
    }
  };

  const values = [
    { title: "Regulatory Mastery", desc: "Deep understanding of SEBI, RBI, FEMA, and IFSC frameworks to ensure bulletproof compliance.", icon: <Scale className="w-6 h-6 text-finBlue" /> },
    { title: "Unbiased Advisory", desc: "Operating on an open-architecture model. Our recommendations are driven purely by data and client needs.", icon: <ShieldCheck className="w-6 h-6 text-finBlue" /> },
    { title: "Global Perspective", desc: "Connecting domestic enterprises with foreign capital, and managing cross-border wealth seamlessly.", icon: <Globe className="w-6 h-6 text-finBlue" /> },
    { title: "Speed of Execution", desc: "Time is capital. Our robust banking relationships and standardized SOPs guarantee faster turnaround times.", icon: <TrendingUp className="w-6 h-6 text-finBlue" /> }
  ];

  return (
    <div className="bg-white overflow-hidden">
      
      {/* --- LEADERSHIP CONTACT MODAL --- */}
      {isModalOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
          <div className="bg-white rounded-2xl w-full max-w-lg shadow-2xl overflow-hidden animate-[fadeIn_0.3s_ease-out]">
            <div className="bg-finBlue p-6 flex justify-between items-center text-white">
              <h3 className="text-xl font-bold flex items-center"><Calendar className="w-5 h-5 mr-2"/> Book Strategy Session</h3>
              <button onClick={() => setIsModalOpen(false)} className="hover:text-finOrange transition"><X className="w-6 h-6" /></button>
            </div>
            <form className="p-8 space-y-4" onSubmit={(e) => { e.preventDefault(); setIsModalOpen(false); alert(`Consultation request for ${selectedLeader} sent successfully! Our executive team will schedule your call.`); }}>
              
              <div className="bg-slate-50 p-3 rounded-lg border border-gray-200 mb-4 text-sm text-gray-600 font-medium flex items-center">
                <Briefcase className="w-4 h-4 text-finOrange mr-2 flex-shrink-0" />
                Requesting consultation regarding: <span className="font-bold text-finBlue ml-1">{selectedLeader === 'General' ? 'Corporate Advisory' : selectedLeader}</span>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Your Name</label>
                <input type="text" required className="w-full border border-gray-300 rounded-lg px-4 py-3 focus:ring-2 focus:ring-finOrange outline-none" placeholder="John Doe" />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Company / Entity</label>
                  <input type="text" className="w-full border border-gray-300 rounded-lg px-4 py-3 focus:ring-2 focus:ring-finOrange outline-none" placeholder="Acme Corp" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Phone Number</label>
                  <input type="tel" required className="w-full border border-gray-300 rounded-lg px-4 py-3 focus:ring-2 focus:ring-finOrange outline-none" placeholder="+91 98765 43210" />
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Corporate Email</label>
                <input type="email" required className="w-full border border-gray-300 rounded-lg px-4 py-3 focus:ring-2 focus:ring-finOrange outline-none" placeholder="director@company.com" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Brief Description of Requirement</label>
                <textarea required rows="3" className="w-full border border-gray-300 rounded-lg px-4 py-3 focus:ring-2 focus:ring-finOrange outline-none resize-none" placeholder="E.g., Looking for SME IPO advisory or ₹10 Cr Working Capital..."></textarea>
              </div>
              <button type="submit" className="w-full bg-finOrange hover:bg-finOrange-dark text-white font-bold py-4 rounded-lg mt-2 flex justify-center items-center transition shadow-lg">
                Submit Request <Send className="w-5 h-5 ml-2" />
              </button>
            </form>
          </div>
        </div>
      )}

      {/* 1. Hero Section */}
      <div className="bg-finBlue text-white py-24 relative overflow-hidden">
        <div className="absolute top-0 right-0 opacity-10 pointer-events-none">
          <Building2 className="w-96 h-96 -mt-10 -mr-10 animate-[pulse_10s_ease-in-out_infinite]" />
        </div>
        <div className="absolute top-1/2 left-0 w-full h-1 bg-gradient-to-r from-transparent via-finOrange/20 to-transparent"></div>
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center">
          <div className="inline-flex items-center justify-center space-x-2 text-finOrange font-bold tracking-wider uppercase text-sm mb-6">
            <Award className="w-5 h-5" />
            <span>Architecting Financial Success</span>
          </div>
          <h1 className="text-4xl md:text-6xl font-extrabold mb-6 leading-tight max-w-4xl mx-auto">
            We don't just advise. <br/><span className="text-finOrange">We execute.</span>
          </h1>
          <p className="text-xl text-gray-300 mb-10 leading-relaxed max-w-3xl mx-auto">
            FIN5IVE is an elite consortium of Chartered Accountants, CMAs, and Corporate Lawyers dedicated to structuring massive capital growth for MSMEs, Corporates, and Global Indians.
          </p>
        </div>
      </div>

      {/* 2. Impact Statistics */}
      <div className="bg-slate-900 text-white py-12 border-b-4 border-finOrange relative z-20 -mt-8 mx-4 sm:mx-8 lg:mx-auto max-w-7xl rounded-3xl shadow-2xl">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center divide-x divide-gray-700">
          <div className="p-4"><p className="text-4xl font-extrabold text-finOrange mb-2">25<span className="text-2xl text-white">+</span></p><p className="text-xs uppercase tracking-widest text-gray-400">Years Experience</p></div>
          <div className="p-4"><p className="text-4xl font-extrabold text-finOrange mb-2">₹1000<span className="text-2xl text-white">Cr+</span></p><p className="text-xs uppercase tracking-widest text-gray-400">Capital Managed</p></div>
          <div className="p-4"><p className="text-4xl font-extrabold text-finOrange mb-2">100<span className="text-2xl text-white">%</span></p><p className="text-xs uppercase tracking-widest text-gray-400">Execution Focus</p></div>
          <div className="p-4"><p className="text-4xl font-extrabold text-finOrange mb-2">4.9<span className="text-2xl text-white">/5</span></p><p className="text-xs uppercase tracking-widest text-gray-400">Client Trust Score</p></div>
        </div>
      </div>

      {/* 3. Interactive Mission/Vision/DNA */}
      <section className="py-24 bg-white border-b border-gray-100 mt-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-finBlue mb-4">The FIN5IVE Philosophy</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">The core principles that drive our strategies and define our relationships with our clients.</p>
          </div>

          <div className="max-w-5xl mx-auto bg-slate-50 border border-gray-200 rounded-3xl overflow-hidden shadow-sm">
            <div className="flex overflow-x-auto scrollbar-hide border-b border-gray-200 bg-white">
              {Object.keys(philosophy).map((key) => (
                <button 
                  key={key}
                  onClick={() => setActiveTab(key)}
                  className={`flex-none md:flex-1 py-5 px-6 text-center font-bold text-sm md:text-lg transition-colors flex flex-row items-center justify-center gap-3 whitespace-nowrap ${activeTab === key ? 'border-b-4 border-finOrange text-finBlue bg-slate-50 shadow-inner' : 'text-gray-400 hover:bg-gray-50 border-b-4 border-transparent'}`}
                >
                  <span className={`${activeTab === key ? 'text-finOrange' : 'text-gray-400'}`}>
                    {philosophy[key].icon}
                  </span>
                  <span>{philosophy[key].title}</span>
                </button>
              ))}
            </div>

            <div className="p-8 md:p-14 transition-all duration-300">
              <div className="flex flex-col md:flex-row gap-12 items-center">
                <div className="md:w-3/5">
                  <h3 className="text-3xl font-bold text-finBlue mb-6">{philosophy[activeTab].title}</h3>
                  <p className="text-gray-600 leading-relaxed text-lg mb-8">{philosophy[activeTab].desc}</p>
                </div>
                
                <div className="md:w-2/5 bg-white p-8 rounded-2xl border border-gray-100 shadow-sm w-full">
                  <h4 className="font-bold text-finBlue mb-6 text-sm uppercase tracking-widest">Key Focus Areas</h4>
                  <ul className="space-y-4">
                    {philosophy[activeTab].points.map((point, i) => (
                      <li key={i} className="flex items-start">
                        <CheckCircle className="w-6 h-6 text-finOrange mt-0.5 mr-4 flex-shrink-0" />
                        <span className="text-gray-700 font-medium">{point}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 4. Leadership Section (Now with Actions) */}
      <section className="py-24 bg-slate-50 border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <span className="text-finOrange font-bold tracking-wider uppercase text-sm mb-4 block">Our Experts</span>
            <h2 className="text-3xl font-bold text-finBlue mb-4">Meet The Leadership</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">Guided by industry veterans with decades of experience in corporate structuring, capital markets, and global wealth management.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 max-w-5xl mx-auto">
            {/* CA Chetan Joshi */}
            <div className="bg-white rounded-3xl shadow-xl border border-gray-100 overflow-hidden group hover:-translate-y-2 transition-all duration-300 flex flex-col">
              <div className="h-80 bg-finBlue relative overflow-hidden flex items-center justify-center">
                <img src="https://ui-avatars.com/api/?name=Chetan+Joshi&background=003366&color=fff&size=512" alt="CA Chetan Joshi" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700 opacity-90" />
                <div className="absolute inset-0 bg-gradient-to-t from-finBlue via-transparent to-transparent opacity-80"></div>
                <div className="absolute bottom-0 left-0 p-6 w-full">
                  <div className="flex justify-between items-end">
                    <div>
                      <h3 className="text-2xl font-bold text-white">CA Chetan Joshi</h3>
                      <p className="text-finOrange font-semibold text-sm mt-1">Founder & Managing Director</p>
                    </div>
                    <a href="https://linkedin.com" target="_blank" rel="noopener noreferrer" className="bg-white/20 p-2 rounded-full hover:bg-finOrange transition backdrop-blur-sm z-20">
                      <Linkedin className="w-5 h-5 text-white" />
                    </a>
                  </div>
                </div>
              </div>
              <div className="p-8 flex-grow flex flex-col justify-between">
                <div>
                  <p className="text-gray-600 leading-relaxed mb-6 text-sm">
                    A seasoned Chartered Accountant with profound expertise in Capital Markets, IPO Structuring, and GIFT City offshore establishment. Chetan brings decades of tier-1 institutional insight to middle-market and large corporate clients.
                  </p>
                  <div className="flex flex-wrap gap-2 mb-8">
                    <span className="bg-slate-100 text-finBlue text-xs px-3 py-1 rounded-full font-semibold">IPO Advisory</span>
                    <span className="bg-slate-100 text-finBlue text-xs px-3 py-1 rounded-full font-semibold">GIFT City IFSC</span>
                    <span className="bg-slate-100 text-finBlue text-xs px-3 py-1 rounded-full font-semibold">Corporate Finance</span>
                  </div>
                </div>
                <button onClick={() => handleOpenModal('CA Chetan Joshi - IPO & GIFT City')} className="w-full bg-slate-50 hover:bg-finBlue hover:text-white text-finBlue border border-gray-200 hover:border-finBlue font-bold py-3 rounded-lg transition-colors duration-300 flex justify-center items-center">
                  Consult with Chetan <ArrowRight className="w-4 h-4 ml-2" />
                </button>
              </div>
            </div>

            {/* CMA Neha Joshi */}
            <div className="bg-white rounded-3xl shadow-xl border border-gray-100 overflow-hidden group hover:-translate-y-2 transition-all duration-300 flex flex-col">
              <div className="h-80 bg-finOrange relative overflow-hidden flex items-center justify-center">
                <img src="https://ui-avatars.com/api/?name=Neha+Joshi&background=FF6600&color=fff&size=512" alt="CMA Neha Joshi" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700 opacity-90" />
                <div className="absolute inset-0 bg-gradient-to-t from-finBlue via-transparent to-transparent opacity-80"></div>
                <div className="absolute bottom-0 left-0 p-6 w-full">
                  <div className="flex justify-between items-end">
                    <div>
                      <h3 className="text-2xl font-bold text-white">CMA Neha Joshi</h3>
                      <p className="text-finOrange font-semibold text-sm mt-1">Co-Founder & Director</p>
                    </div>
                    <a href="https://linkedin.com" target="_blank" rel="noopener noreferrer" className="bg-white/20 p-2 rounded-full hover:bg-finOrange transition backdrop-blur-sm z-20">
                      <Linkedin className="w-5 h-5 text-white" />
                    </a>
                  </div>
                </div>
              </div>
              <div className="p-8 flex-grow flex flex-col justify-between">
                <div>
                  <p className="text-gray-600 leading-relaxed mb-6 text-sm">
                    A highly credentialed Cost and Management Accountant specializing in MSME financial engineering. Neha architects massive cost-reduction strategies through precision Working Capital funding, ZED certifications, and Government Subsidies.
                  </p>
                  <div className="flex flex-wrap gap-2 mb-8">
                    <span className="bg-slate-100 text-finBlue text-xs px-3 py-1 rounded-full font-semibold">MSME Funding</span>
                    <span className="bg-slate-100 text-finBlue text-xs px-3 py-1 rounded-full font-semibold">ZED Certification</span>
                    <span className="bg-slate-100 text-finBlue text-xs px-3 py-1 rounded-full font-semibold">Subsidies</span>
                  </div>
                </div>
                <button onClick={() => handleOpenModal('CMA Neha Joshi - MSME Funding & ZED')} className="w-full bg-slate-50 hover:bg-finOrange hover:text-white text-finBlue border border-gray-200 hover:border-finOrange font-bold py-3 rounded-lg transition-colors duration-300 flex justify-center items-center">
                  Consult with Neha <ArrowRight className="w-4 h-4 ml-2" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 5. Core Values Grid */}
      <section className="py-24 bg-white border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-finBlue mb-4">Why Businesses Trust FIN5IVE</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">We operate differently than traditional consultancy firms. Our approach is deeply embedded in your success.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {values.map((val, i) => (
              <div key={i} className="bg-slate-50 p-8 rounded-2xl border border-gray-100 hover:shadow-lg hover:border-finOrange/30 transition-all duration-300">
                <div className="bg-white w-14 h-14 rounded-xl flex items-center justify-center shadow-sm mb-6">
                  {val.icon}
                </div>
                <h3 className="font-bold text-finBlue text-lg mb-3">{val.title}</h3>
                <p className="text-gray-600 text-sm leading-relaxed">{val.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 6. Global Network & Partners (Marquee & Visuals) */}
      <section className="py-24 bg-finBlue text-white relative overflow-hidden">
        <Globe className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] text-white opacity-5 animate-[spin_200s_linear_infinite] pointer-events-none" />
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center">
          <h2 className="text-3xl font-bold mb-6">Our Marquee Network</h2>
          <p className="text-gray-300 max-w-2xl mx-auto mb-16 text-lg">
            We hold strong empanelments and direct associations with India's leading banks, AMCs, stock exchanges, and regulatory authorities.
          </p>

          <div className="bg-white/10 backdrop-blur-md border border-white/20 rounded-3xl p-10 md:p-16">
            <p className="text-finOrange font-bold tracking-widest uppercase text-sm mb-10">Empanelled With & Regulated By</p>
            
            <div className="flex flex-wrap justify-center gap-6 md:gap-12 opacity-80">
              <div className="flex items-center px-6 py-3 bg-white/5 rounded-lg border border-white/10"><span className="text-xl font-bold tracking-tight">NSE Emerge</span></div>
              <div className="flex items-center px-6 py-3 bg-white/5 rounded-lg border border-white/10"><span className="text-xl font-bold tracking-tight">BSE SME</span></div>
              <div className="flex items-center px-6 py-3 bg-white/5 rounded-lg border border-white/10"><span className="text-xl font-bold tracking-tight">GIFT City IFSC</span></div>
              <div className="flex items-center px-6 py-3 bg-white/5 rounded-lg border border-white/10"><span className="text-xl font-bold tracking-tight">MSME - QCI</span></div>
              <div className="flex items-center px-6 py-3 bg-white/5 rounded-lg border border-white/10"><span className="text-xl font-bold tracking-tight">Top AMFI Entities</span></div>
            </div>
          </div>
        </div>
      </section>

      {/* 7. Final Call to Action (Now fully functional) */}
      <section className="py-24 bg-slate-50">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-white rounded-3xl p-10 md:p-16 text-center shadow-xl border border-gray-100 relative overflow-hidden">
            <div className="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-finBlue via-finOrange to-finBlue"></div>
            <h2 className="text-3xl md:text-4xl font-extrabold text-finBlue mb-6">
              Ready to Accelerate Your Growth?
            </h2>
            <p className="text-lg text-gray-600 mb-10 max-w-2xl mx-auto">
              Whether you are preparing for an IPO, seeking massive working capital, or structuring your cross-border wealth—our leadership is ready to partner with you.
            </p>
            <div className="flex flex-col sm:flex-row justify-center gap-4 relative z-10">
              <button onClick={() => handleOpenModal('General')} className="bg-finBlue hover:bg-finBlue-light text-white font-bold py-4 px-10 rounded-lg shadow-lg transform hover:-translate-y-0.5 transition-all duration-300 flex items-center justify-center">
                Contact Leadership <ArrowRight className="ml-2 w-5 h-5" />
              </button>
              
              {/* This button now triggers a functional mailto: link */}
              <a href="mailto:info@fin5ive.com?subject=Inquiry%20from%20Website" className="bg-slate-100 hover:bg-slate-200 text-finBlue font-bold py-4 px-10 rounded-lg transition-all duration-300 flex items-center justify-center border border-gray-200 hover:border-gray-300">
                <Mail className="w-5 h-5 mr-2" /> Email Us Directly
              </a>
            </div>
          </div>
        </div>
      </section>

    </div>
  );
};

export default About;