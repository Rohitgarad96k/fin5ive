import React, { useState, useEffect } from 'react';
import { 
  ArrowRight, ShieldCheck, TrendingUp, Users, Award, Building2, 
  Briefcase, Calculator, ChevronDown, ChevronUp, Star, Quote, 
  CheckCircle, Mail, LineChart 
} from 'lucide-react';
import Hero from '../components/Hero';
import ServicesGrid from '../components/ServicesGrid';

const Home = () => {
  // --- STATE MANAGEMENT ---
  
  // 1. Calculator State
  const [calcType, setCalcType] = useState('SIP'); // 'SIP' or 'LUMPSUM'
  const [investment, setInvestment] = useState(25000);
  const [years, setYears] = useState(10);
  const [returnRate, setReturnRate] = useState(12);

  // 2. FAQ State
  const [activeFaq, setActiveFaq] = useState(0);

  // 3. Testimonial Slider State
  const [testimonialIdx, setTestimonialIdx] = useState(0);

  // --- CALCULATOR MATH ---
  const calculateReturns = () => {
    const r = returnRate / 100;
    const months = years * 12;
    let totalInvested = 0;
    let maturityValue = 0;

    if (calcType === 'SIP') {
      const monthlyRate = r / 12;
      totalInvested = investment * months;
      maturityValue = Math.round(investment * ((Math.pow(1 + monthlyRate, months) - 1) / monthlyRate) * (1 + monthlyRate));
    } else {
      totalInvested = investment;
      maturityValue = Math.round(investment * Math.pow(1 + r, years));
    }

    return { totalInvested, maturityValue, wealthGained: maturityValue - totalInvested };
  };

  const { totalInvested, maturityValue, wealthGained } = calculateReturns();
  const formatINR = (value) => new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(value);

  // --- DATA ARRAYS ---
  const faqs = [
    { question: "What is the minimum ticket size for Working Capital funding?", answer: "We arrange working capital facilities ranging from ₹30 Lakhs up to ₹25 Crores, including Cash Credit (CC), Overdrafts, and CGTMSE unsecured loans." },
    { question: "Do you assist with the entire GIFT City IFSC setup process?", answer: "Yes. We are an end-to-end implementation partner. We handle MCA Name Reservation, SEZ Approval, IFSCA Registration, and post-establishment compliance." },
    { question: "How fast can Export Trade Finance be disbursed?", answer: "For eligible exporters, we can arrange collateral-free working capital up to $2.5 Million with disbursal in less than 24 hours of invoice submission." },
    { question: "Who handles the Wealth Management & Investment portfolios?", answer: "Our wealth management team consists of NISM and RERA certified professionals with decades of experience structuring portfolios for HNIs, NRIs, and Corporates." }
  ];

  const testimonials = [
    { text: "FIN5IVE completely restructured our debt. Their advisory on MSME subsidies reduced our interest burden significantly, allowing us to expand our manufacturing unit.", author: "Rajesh P.", role: "Director, Auto-Ancillary MSME" },
    { text: "The GIFT City setup process seemed daunting, but the team at FIN5IVE navigated the SEZ and IFSCA approvals flawlessly. A truly elite corporate finance team.", author: "Sarah M.", role: "CEO, Global Fintech Fund" },
    { text: "Their export factoring services solved our cash flow bottleneck overnight. Getting 80% advance on our international invoices within 24 hours changed our business.", author: "Amit V.", role: "Founder, Export Trading House" }
  ];

  const nextTestimonial = () => setTestimonialIdx((prev) => (prev + 1) % testimonials.length);
  const prevTestimonial = () => setTestimonialIdx((prev) => (prev - 1 + testimonials.length) % testimonials.length);

  return (
    <div className="bg-white">
      
      {/* 0. NEW: Market Ticker (Top Bar) */}
      <div className="bg-finBlue-dark text-white text-xs py-2 overflow-hidden flex border-b border-white/10">
        <div className="animate-[marquee_20s_linear_infinite] whitespace-nowrap flex space-x-8 px-4 items-center">
          <span className="flex items-center"><TrendingUp className="w-3 h-3 text-green-400 mr-1"/> NIFTY 50: 22,514 <span className="text-green-400 ml-1">(+0.4%)</span></span>
          <span className="flex items-center"><TrendingUp className="w-3 h-3 text-green-400 mr-1"/> SENSEX: 74,228 <span className="text-green-400 ml-1">(+0.5%)</span></span>
          <span className="flex items-center"><LineChart className="w-3 h-3 text-finOrange mr-1"/> GOLD: ₹71,200</span>
          <span className="flex items-center text-gray-300">|</span>
          <span className="text-finOrange font-semibold">Latest News:</span>
          <span>RBI keeps repo rate unchanged at 6.5%</span>
          <span>SEBI announces new IPO regulations for SME platforms</span>
        </div>
      </div>

      {/* 1. Hero Section */}
      <Hero />

      {/* 2. Trust Marquee */}
      <section className="py-8 bg-slate-50 border-b border-gray-100 overflow-hidden shadow-inner">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <p className="text-center text-xs font-bold text-gray-400 tracking-widest uppercase mb-6">
            Trusted By & Empanelled With Leading Institutions
          </p>
          <div className="flex flex-wrap justify-center gap-10 md:gap-20 opacity-50 grayscale hover:grayscale-0 transition-all duration-500 items-center">
            <span className="text-xl md:text-2xl font-bold text-gray-800 tracking-tight">HDFC MF</span>
            <span className="text-xl md:text-2xl font-bold text-gray-800 tracking-tight">SBI Mutual Fund</span>
            <span className="text-xl md:text-2xl font-bold text-gray-800 tracking-tight">ICICI Prudential</span>
            <span className="text-xl md:text-2xl font-bold text-gray-800 tracking-tight">NSE Emerge</span>
            <span className="text-xl md:text-2xl font-bold text-gray-800 tracking-tight">BSE SME</span>
          </div>
        </div>
      </section>

      {/* 3. Services Grid */}
      <ServicesGrid />

      {/* 4. The FIN5IVE Advantage (Why Choose Us) */}
      <section className="py-24 bg-white relative overflow-hidden border-t border-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="text-center mb-16">
            <span className="text-finOrange font-bold tracking-wider uppercase text-sm mb-4 block">Our DNA</span>
            <h2 className="text-3xl md:text-4xl font-extrabold text-finBlue mb-4">Architecting Financial Success</h2>
            <p className="mt-4 max-w-2xl mx-auto text-xl text-gray-500">
              We aren't just consultants; we are execution partners. Our in-house elite team ensures end-to-end delivery from structuring to disbursement.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              { title: "Elite In-House Team", desc: "Led by highly qualified Chartered Accountants, CMAs, and Corporate Lawyers.", icon: <Users className="w-8 h-8 text-finOrange" /> },
              { title: "25+ Years Experience", desc: "Decades of combined leadership experience navigating complex corporate finance.", icon: <Award className="w-8 h-8 text-finOrange" /> },
              { title: "Marquee Network", desc: "Direct access to QIBs, Ultra HNIs, Top Banks, and Global AMCs.", icon: <Building2 className="w-8 h-8 text-finOrange" /> },
              { title: "Regulatory Mastery", desc: "Flawless liaison with SEBI, RBI, FEMA, and IFSC authorities.", icon: <ShieldCheck className="w-8 h-8 text-finOrange" /> },
            ].map((feature, i) => (
              <div key={i} className="bg-slate-50 p-8 rounded-2xl border border-gray-100 hover:shadow-xl hover:border-finOrange/30 hover:-translate-y-1 transition-all duration-300">
                <div className="bg-white shadow-sm border border-gray-100 w-16 h-16 rounded-xl flex items-center justify-center mb-6">
                  {feature.icon}
                </div>
                <h3 className="text-xl font-bold text-finBlue mb-3">{feature.title}</h3>
                <p className="text-gray-600 text-sm leading-relaxed">{feature.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 5. Interactive Wealth Calculator */}
      <section className="py-24 bg-slate-50 border-t border-b border-gray-100 relative overflow-hidden">
        {/* Background glow */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-3/4 h-3/4 bg-finOrange/5 blur-[100px] rounded-full pointer-events-none"></div>
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-finBlue mb-4">Interactive Wealth Planner</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">Model your financial future. Toggle between Monthly SIPs or One-Time Lumpsum investments to visualize the power of compounding.</p>
          </div>

          <div className="bg-white rounded-3xl shadow-2xl border border-gray-100 overflow-hidden max-w-5xl mx-auto">
            
            {/* Toggle SIP / Lumpsum */}
            <div className="flex border-b border-gray-100">
              <button 
                onClick={() => setCalcType('SIP')}
                className={`flex-1 py-4 text-center font-bold text-lg transition-colors ${calcType === 'SIP' ? 'bg-finBlue text-white' : 'bg-white text-gray-500 hover:bg-gray-50'}`}
              >
                Monthly SIP
              </button>
              <button 
                onClick={() => setCalcType('LUMPSUM')}
                className={`flex-1 py-4 text-center font-bold text-lg transition-colors ${calcType === 'LUMPSUM' ? 'bg-finBlue text-white' : 'bg-white text-gray-500 hover:bg-gray-50'}`}
              >
                One-Time Lumpsum
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2">
              {/* Sliders Side */}
              <div className="p-8 md:p-12 border-b md:border-b-0 md:border-r border-gray-100">
                <div className="mb-8">
                  <div className="flex justify-between items-center mb-4">
                    <label className="font-semibold text-gray-700">{calcType === 'SIP' ? 'Monthly Investment' : 'Total Investment'}</label>
                    <div className="bg-slate-50 border border-gray-200 px-4 py-2 rounded-lg font-bold text-finBlue">
                      {formatINR(investment)}
                    </div>
                  </div>
                  <input 
                    type="range" min={calcType === 'SIP' ? "1000" : "50000"} max={calcType === 'SIP' ? "200000" : "5000000"} step={calcType === 'SIP' ? "1000" : "50000"} 
                    value={investment} onChange={(e) => setInvestment(Number(e.target.value))}
                    className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-finOrange"
                  />
                </div>

                <div className="mb-8">
                  <div className="flex justify-between items-center mb-4">
                    <label className="font-semibold text-gray-700">Time Period</label>
                    <div className="bg-slate-50 border border-gray-200 px-4 py-2 rounded-lg font-bold text-finBlue">{years} Years</div>
                  </div>
                  <input 
                    type="range" min="1" max="30" step="1" 
                    value={years} onChange={(e) => setYears(Number(e.target.value))}
                    className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-finOrange"
                  />
                </div>

                <div className="mb-4">
                  <div className="flex justify-between items-center mb-4">
                    <label className="font-semibold text-gray-700">Expected Annual Return</label>
                    <div className="bg-slate-50 border border-gray-200 px-4 py-2 rounded-lg font-bold text-finBlue">{returnRate}%</div>
                  </div>
                  <input 
                    type="range" min="5" max="25" step="0.5" 
                    value={returnRate} onChange={(e) => setReturnRate(Number(e.target.value))}
                    className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-finOrange"
                  />
                </div>
              </div>

              {/* Output Side */}
              <div className="p-8 md:p-12 bg-slate-50 flex flex-col justify-center">
                <div className="space-y-6 mb-8">
                  <div className="flex justify-between items-center">
                    <p className="text-gray-500 font-medium">Invested Amount</p>
                    <p className="text-xl font-bold text-gray-800">{formatINR(totalInvested)}</p>
                  </div>
                  <div className="flex justify-between items-center">
                    <p className="text-gray-500 font-medium">Est. Wealth Gained</p>
                    <p className="text-xl font-bold text-green-600">+{formatINR(wealthGained)}</p>
                  </div>
                  <div className="pt-6 border-t border-gray-200">
                    <p className="text-gray-500 font-medium mb-2">Total Future Value</p>
                    <p className="text-5xl font-extrabold text-finBlue">{formatINR(maturityValue)}</p>
                  </div>
                </div>
                <button className="w-full bg-finOrange hover:bg-finOrange-light text-white font-bold py-4 rounded-lg transition duration-300 shadow-lg shadow-finOrange/30 flex justify-center items-center text-lg">
                  Start Investing <ArrowRight className="ml-2 w-5 h-5" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 6. Testimonials Slider */}
      <section className="py-24 bg-white">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <span className="text-finOrange font-bold tracking-wider uppercase text-sm mb-4 block">Client Success</span>
          <h2 className="text-3xl font-bold text-finBlue mb-12">Trusted by Industry Leaders</h2>
          
          <div className="bg-finBlue text-white rounded-3xl p-10 md:p-16 relative shadow-2xl">
            <Quote className="absolute top-8 left-8 w-16 h-16 text-white/10" />
            <div className="relative z-10">
              <div className="flex justify-center mb-6">
                {[1, 2, 3, 4, 5].map(star => <Star key={star} className="w-5 h-5 text-finOrange fill-current mx-1" />)}
              </div>
              <p className="text-xl md:text-2xl font-medium leading-relaxed mb-10 italic">"{testimonials[testimonialIdx].text}"</p>
              <div>
                <p className="font-bold text-lg">{testimonials[testimonialIdx].author}</p>
                <p className="text-finOrange text-sm">{testimonials[testimonialIdx].role}</p>
              </div>
            </div>
            
            {/* Slider Controls */}
            <div className="absolute bottom-8 right-8 flex space-x-2">
              <button onClick={prevTestimonial} className="w-10 h-10 rounded-full border border-white/20 flex items-center justify-center hover:bg-white/10 transition">←</button>
              <button onClick={nextTestimonial} className="w-10 h-10 rounded-full border border-white/20 flex items-center justify-center hover:bg-white/10 transition">→</button>
            </div>
          </div>
        </div>
      </section>

      {/* 7. Leadership Team */}
      <section className="py-24 bg-slate-50 border-t border-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-finBlue mb-4">Meet The Leadership</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">Guided by industry veterans with over 25 years of combined experience in corporate finance, compliance, and wealth management.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden text-center group hover:shadow-xl transition-all">
              <div className="h-72 bg-slate-200 overflow-hidden relative">
                <img src="https://ui-avatars.com/api/?name=Chetan+Joshi&background=003366&color=fff&size=512" alt="CA Chetan Joshi" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
              </div>
              <div className="p-8">
                <h3 className="text-xl font-bold text-finBlue">CA Chetan Joshi</h3>
                <p className="text-finOrange font-semibold text-sm mt-1">Founder & Managing Director</p>
              </div>
            </div>

            <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden text-center group hover:shadow-xl transition-all">
              <div className="h-72 bg-slate-200 overflow-hidden">
                <img src="https://ui-avatars.com/api/?name=Neha+Joshi&background=FF6600&color=fff&size=512" alt="CMA Neha Joshi" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
              </div>
              <div className="p-8">
                <h3 className="text-xl font-bold text-finBlue">CMA Neha Joshi</h3>
                <p className="text-finOrange font-semibold text-sm mt-1">Co-Founder & Director</p>
              </div>
            </div>

            <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden text-center flex flex-col justify-center items-center p-8 bg-gradient-to-b from-white to-slate-50">
               <Users className="w-16 h-16 text-finBlue/20 mb-6" />
               <h3 className="text-xl font-bold text-finBlue">Advisory Board</h3>
               <p className="text-finOrange font-semibold text-sm mt-1 mb-4">Legal & Compliance</p>
               <p className="text-gray-500 text-sm">Supported by a dedicated network of Company Secretaries, Lawyers, and Ex-Bankers.</p>
            </div>
          </div>
        </div>
      </section>

      {/* 8. Scale Statistics */}
      <section className="py-16 bg-finBlue border-y-4 border-finOrange text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center divide-x divide-white/10">
            <div className="p-2">
              <p className="text-4xl md:text-5xl font-extrabold mb-2">₹25<span className="text-finOrange text-3xl">Cr</span></p>
              <p className="text-sm text-gray-300 uppercase tracking-widest">Max WC Funding</p>
            </div>
            <div className="p-2">
              <p className="text-4xl md:text-5xl font-extrabold mb-2">&lt;24<span className="text-finOrange text-3xl">hr</span></p>
              <p className="text-sm text-gray-300 uppercase tracking-widest">Export Disbursals</p>
            </div>
            <div className="p-2">
              <p className="text-4xl md:text-5xl font-extrabold mb-2">100<span className="text-finOrange text-3xl">%</span></p>
              <p className="text-sm text-gray-300 uppercase tracking-widest">Machinery Finance</p>
            </div>
            <div className="p-2">
              <p className="text-4xl md:text-5xl font-extrabold mb-2">25<span className="text-finOrange text-3xl">+</span></p>
              <p className="text-sm text-gray-300 uppercase tracking-widest">Years Expertise</p>
            </div>
          </div>
        </div>
      </section>

      {/* 9. Interactive FAQ */}
      <section className="py-24 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-finBlue mb-4">Frequently Asked Questions</h2>
            <p className="text-gray-600">Clear answers to help you make informed financial decisions.</p>
          </div>
          <div className="space-y-4">
            {faqs.map((faq, index) => (
              <div key={index} className="border border-gray-200 rounded-lg overflow-hidden transition-all duration-300">
                <button 
                  onClick={() => setActiveFaq(activeFaq === index ? null : index)}
                  className="w-full flex justify-between items-center p-6 bg-slate-50 hover:bg-gray-100 transition text-left"
                >
                  <span className="font-bold text-finBlue text-lg">{faq.question}</span>
                  {activeFaq === index ? <ChevronUp className="w-5 h-5 text-finOrange" /> : <ChevronDown className="w-5 h-5 text-gray-400" />}
                </button>
                <div className={`px-6 overflow-hidden transition-all duration-300 ${activeFaq === index ? 'max-h-40 py-6 bg-white' : 'max-h-0 py-0'}`}>
                  <p className="text-gray-600 leading-relaxed">{faq.answer}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 10. Newsletter Lead Capture */}
      <section className="py-20 bg-slate-50 border-t border-gray-100">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <Mail className="w-12 h-12 text-finOrange mx-auto mb-6" />
          <h2 className="text-3xl font-bold text-finBlue mb-4">Stay Ahead of the Markets</h2>
          <p className="text-gray-600 mb-8">Join our exclusive mailing list for HNI investment strategies, IPO updates, and MSME subsidy alerts.</p>
          <form className="flex flex-col sm:flex-row gap-4 max-w-2xl mx-auto" onSubmit={(e) => e.preventDefault()}>
            <input 
              type="email" 
              placeholder="Enter your corporate email address" 
              className="flex-1 px-6 py-4 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-finOrange focus:border-transparent"
            />
            <button className="bg-finBlue hover:bg-finBlue-light text-white font-bold py-4 px-8 rounded-lg transition duration-300 whitespace-nowrap">
              Subscribe Now
            </button>
          </form>
        </div>
      </section>

      {/* 11. Final CTA */}
      <section className="py-24 bg-white border-t border-gray-100">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-gradient-to-br from-finOrange to-finOrange-dark rounded-3xl p-10 md:p-16 text-center shadow-2xl relative overflow-hidden">
            <TrendingUp className="absolute -bottom-10 -right-10 w-64 h-64 text-white opacity-20" />
            <div className="relative z-10">
              <h2 className="text-3xl md:text-5xl font-extrabold text-white mb-6 leading-tight">
                Ready to Accelerate Your Growth?
              </h2>
              <p className="text-lg md:text-xl text-white/90 mb-10 max-w-2xl mx-auto">
                Whether you're looking for global expansion in GIFT City, planning an IPO, or seeking seamless working capital.
              </p>
              <button className="bg-finBlue hover:bg-finBlue-light text-white font-bold py-4 px-12 rounded-lg shadow-lg transform hover:-translate-y-0.5 transition-all duration-300 text-lg">
                Book a Free Consultation
              </button>
            </div>
          </div>
        </div>
      </section>

    </div>
  );
};

export default Home;