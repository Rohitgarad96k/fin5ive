import React, { useState } from 'react';
import { 
  TrendingUp, ShieldCheck, Globe, Building2, Award, Briefcase, 
  ArrowRight, CheckCircle, PieChart, Target, BarChart, X, Send, 
  ChevronDown, ChevronUp, Download, Mail, Activity, Landmark
} from 'lucide-react';

const InvestmentServices = () => {
  // --- STATE MANAGEMENT ---
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [activeTab, setActiveTab] = useState('PMS');
  const [activeFaq, setActiveFaq] = useState(null);

  // Calculator State
  const [investmentAmount, setInvestmentAmount] = useState(10000000); // 1 Crore Default
  const [timeHorizon, setTimeHorizon] = useState(10); // 10 Years
  const [riskProfile, setRiskProfile] = useState('BALANCED'); // CONSERVATIVE, BALANCED, AGGRESSIVE

  // --- CALCULATOR MATH & PROFILES ---
  const profiles = {
    CONSERVATIVE: { return: 8, equity: 20, debt: 70, gold: 10 },
    BALANCED: { return: 12, equity: 60, debt: 30, gold: 10 },
    AGGRESSIVE: { return: 15, equity: 85, debt: 10, gold: 5 }
  };

  const currentProfile = profiles[riskProfile];
  const rate = currentProfile.return / 100;
  const projectedWealth = investmentAmount * Math.pow(1 + rate, timeHorizon);
  const wealthGained = projectedWealth - investmentAmount;

  const formatINR = (value) => new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(value);

  // --- DATA ARRAYS ---
  const offerings = {
    MF: { 
      title: "Mutual Funds", 
      icon: <PieChart className="w-6 h-6" />, 
      desc: "Data-driven scheme selection across Top AMCs. We build diversified core portfolios tailored to your financial goals, optimizing for alpha generation and risk mitigation.",
      points: ["Goal-based financial planning", "Direct access to top-performing AMCs", "Regular portfolio rebalancing", "Tax-saving (ELSS) strategies"]
    },
    PMS: { 
      title: "Portfolio Management Services", 
      icon: <Target className="w-6 h-6" />, 
      desc: "Bespoke equity portfolios managed by elite fund managers. Designed for HNIs seeking concentrated bets, thematic investments, and active wealth creation.",
      points: ["Minimum ticket size: ₹50 Lakhs", "Transparent holding structures", "Customized thematic strategies", "Direct equity exposure"]
    },
    AIF: { 
      title: "Alternative Investment Funds", 
      icon: <BarChart className="w-6 h-6" />, 
      desc: "Exclusive access to sophisticated Category I, II, and III AIFs. Participate in private equity, venture debt, and complex absolute-return strategies.",
      points: ["Minimum ticket size: ₹1 Crore", "Access to unlisted & private markets", "Global outbound tech/AI funds", "Inbound India growth funds"]
    },
    RE: { 
      title: "Real Estate Advisory", 
      icon: <Building2 className="w-6 h-6" />, 
      desc: "RERA-certified advisory for commercial and premium residential real estate. We help you build a tangible, high-yield asset base alongside financial assets.",
      points: ["High-yield commercial properties", "Pre-leased asset investments", "Fractional real estate options", "Thorough legal due diligence"]
    }
  };

  const faqs = [
    { question: "What is the minimum portfolio size you manage?", answer: "While we advise clients across various wealth brackets, our specialized services like PMS require a regulatory minimum of ₹50 Lakhs, and AIFs require a minimum commitment of ₹1 Crore." },
    { question: "Are your investment recommendations biased towards specific AMCs?", answer: "Absolutely not. As NISM-certified professionals, we operate on an open-architecture platform. Our recommendations are purely data-driven, unbiased, and aligned solely with your risk-return profile." },
    { question: "Do you assist NRIs with wealth management in India?", answer: "Yes, NRI wealth management is one of our core pillars. We handle NRE/NRO investments, FEMA compliance, and repatriation strategies alongside portfolio management." },
    { question: "How frequently is my portfolio reviewed?", answer: "We provide real-time dashboard access to your investments. Formal portfolio reviews are conducted quarterly or semi-annually, depending on market volatility and client preference." }
  ];

  return (
    <div className="bg-white relative">

      {/* --- HNI CONSULTATION MODAL --- */}
      {isModalOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
          <div className="bg-white rounded-2xl w-full max-w-lg shadow-2xl overflow-hidden animate-[fadeIn_0.3s_ease-out]">
            <div className="bg-finBlue p-6 flex justify-between items-center text-white">
              <h3 className="text-xl font-bold flex items-center"><Briefcase className="w-5 h-5 mr-2"/> Wealth Consultation</h3>
              <button onClick={() => setIsModalOpen(false)} className="hover:text-finOrange transition"><X className="w-6 h-6" /></button>
            </div>
            <form className="p-8 space-y-4" onSubmit={(e) => { e.preventDefault(); setIsModalOpen(false); alert("Request Received. An advisor will contact you shortly."); }}>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">First Name</label>
                  <input type="text" required className="w-full border border-gray-300 rounded-lg px-4 py-3 focus:ring-2 focus:ring-finOrange outline-none" placeholder="First Name" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Last Name</label>
                  <input type="text" required className="w-full border border-gray-300 rounded-lg px-4 py-3 focus:ring-2 focus:ring-finOrange outline-none" placeholder="Last Name" />
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Email Address</label>
                <input type="email" required className="w-full border border-gray-300 rounded-lg px-4 py-3 focus:ring-2 focus:ring-finOrange outline-none" placeholder="you@email.com" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Investor Profile</label>
                <select className="w-full border border-gray-300 rounded-lg px-4 py-3 focus:ring-2 focus:ring-finOrange outline-none bg-white">
                  <option>Resident Indian (HNI)</option>
                  <option>Non-Resident Indian (NRI)</option>
                  <option>Corporate Treasury</option>
                  <option>Family Office</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Estimated Investable Corpus</label>
                <select className="w-full border border-gray-300 rounded-lg px-4 py-3 focus:ring-2 focus:ring-finOrange outline-none bg-white">
                  <option>₹50 Lakhs - ₹1 Crore</option>
                  <option>₹1 Crore - ₹5 Crores</option>
                  <option>₹5 Crores - ₹20 Crores</option>
                  <option>₹20 Crores+</option>
                </select>
              </div>
              <button type="submit" className="w-full bg-finOrange hover:bg-finOrange-dark text-white font-bold py-4 rounded-lg mt-4 flex justify-center items-center transition shadow-lg">
                Request Callback <Send className="w-5 h-5 ml-2" />
              </button>
            </form>
          </div>
        </div>
      )}

      {/* 1. Epic Hero Section */}
      <div className="bg-finBlue text-white py-24 relative overflow-hidden">
        <div className="absolute top-0 right-0 opacity-10">
          <TrendingUp className="w-96 h-96 -mt-10 -mr-10 animate-[pulse_10s_ease-in-out_infinite]" />
        </div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="max-w-3xl">
            <div className="flex items-center space-x-2 text-finOrange font-bold tracking-wider uppercase text-sm mb-4">
              <Building2 className="w-5 h-5" />
              <span>Private Wealth Management</span>
            </div>
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-extrabold mb-6 leading-tight">
              Strategic Portfolio Management for <span className="text-finOrange">HNIs & Corporates.</span>
            </h1>
            <p className="text-xl text-gray-300 mb-10 leading-relaxed max-w-2xl">
              Unbiased, data-driven investment strategies. From Mutual Funds and PMS to exclusive Category III AIFs, we build resilient portfolios designed for generational wealth.
            </p>
            <div className="flex gap-4">
              <button onClick={() => setIsModalOpen(true)} className="bg-finOrange hover:bg-finOrange-light text-white font-bold py-4 px-8 rounded-lg transition duration-300 shadow-lg shadow-finOrange/30 flex justify-center items-center">
                Schedule a Wealth Consultation <ArrowRight className="ml-2 w-5 h-5" />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* 2. Animated AMC Partners Marquee */}
      <section className="py-8 bg-slate-50 border-b border-gray-100 overflow-hidden shadow-inner">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center">
          <p className="text-xs font-bold text-gray-400 tracking-widest uppercase mr-8 whitespace-nowrap hidden md:block">
            Empanelled With Top AMCs
          </p>
          <div className="flex overflow-hidden relative w-full">
            <div className="animate-[marquee_30s_linear_infinite] whitespace-nowrap flex space-x-12 opacity-60 grayscale hover:grayscale-0 transition-all duration-500 items-center">
              {['HDFC', 'SBI', 'ICICI Prudential', 'Tata', 'Kotak', 'Nippon India', 'Axis', 'Mirae Asset', 'DSP', 'Franklin Templeton', 'HDFC', 'SBI', 'ICICI Prudential'].map((amc, i) => (
                <span key={i} className="text-xl font-bold text-gray-800 tracking-tight">{amc} Mutual Fund</span>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* 3. NEW: Dynamic Asset Allocation Simulator */}
      <section className="py-24 bg-white border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <span className="text-finOrange font-bold tracking-wider uppercase text-sm mb-4 block">Portfolio Modeler</span>
            <h2 className="text-3xl font-bold text-finBlue mb-4">Project Your Wealth Creation</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">Select a risk profile to see the optimal asset mix and calculate the compounding effect on your Lumpsum investment over time.</p>
          </div>

          <div className="bg-slate-50 rounded-3xl shadow-xl border border-gray-200 overflow-hidden max-w-5xl mx-auto flex flex-col md:flex-row">
            
            {/* Input Side */}
            <div className="p-8 md:p-12 md:w-3/5 border-b md:border-b-0 md:border-r border-gray-200">
              
              {/* Risk Profile Selector */}
              <div className="mb-10">
                <label className="font-bold text-gray-700 text-sm mb-4 block">Select Risk Profile</label>
                <div className="grid grid-cols-3 gap-2">
                  {['CONSERVATIVE', 'BALANCED', 'AGGRESSIVE'].map(profile => (
                    <button 
                      key={profile}
                      onClick={() => setRiskProfile(profile)}
                      className={`py-3 rounded-lg font-bold text-xs md:text-sm transition-all ${riskProfile === profile ? 'bg-finBlue text-white shadow-md' : 'bg-white border border-gray-200 text-gray-500 hover:bg-gray-100'}`}
                    >
                      {profile}
                    </button>
                  ))}
                </div>
              </div>

              {/* Sliders */}
              <div className="space-y-8">
                <div>
                  <div className="flex justify-between items-center mb-4">
                    <label className="font-bold text-finBlue">Initial Investment</label>
                    <div className="bg-white border border-gray-200 px-4 py-2 rounded-lg font-bold text-finOrange shadow-sm">
                      {formatINR(investmentAmount)}
                    </div>
                  </div>
                  <input 
                    type="range" min="1000000" max="500000000" step="1000000" 
                    value={investmentAmount} onChange={(e) => setInvestmentAmount(Number(e.target.value))}
                    className="w-full h-2 bg-gray-300 rounded-lg appearance-none cursor-pointer accent-finBlue"
                  />
                  <div className="flex justify-between text-xs font-bold text-gray-400 mt-2">
                    <span>₹10L</span><span>₹50Cr</span>
                  </div>
                </div>

                <div>
                  <div className="flex justify-between items-center mb-4">
                    <label className="font-bold text-finBlue">Time Horizon (Years)</label>
                    <div className="bg-white border border-gray-200 px-4 py-2 rounded-lg font-bold text-finOrange shadow-sm">
                      {timeHorizon} Years
                    </div>
                  </div>
                  <input 
                    type="range" min="1" max="30" step="1" 
                    value={timeHorizon} onChange={(e) => setTimeHorizon(Number(e.target.value))}
                    className="w-full h-2 bg-gray-300 rounded-lg appearance-none cursor-pointer accent-finBlue"
                  />
                </div>
              </div>
            </div>

            {/* Output Side */}
            <div className="p-8 md:p-12 md:w-2/5 bg-finBlue text-white relative flex flex-col justify-center">
              <Activity className="absolute bottom-0 right-0 w-48 h-48 opacity-10" />
              
              <div className="relative z-10">
                <h3 className="text-gray-300 font-bold tracking-widest uppercase text-xs mb-6">Suggested Asset Mix</h3>
                
                {/* Visual Asset Allocation Bar */}
                <div className="flex h-4 rounded-full overflow-hidden mb-4 bg-gray-700">
                  <div style={{width: `${currentProfile.equity}%`}} className="bg-finOrange h-full" title={`Equity: ${currentProfile.equity}%`}></div>
                  <div style={{width: `${currentProfile.debt}%`}} className="bg-blue-400 h-full" title={`Debt: ${currentProfile.debt}%`}></div>
                  <div style={{width: `${currentProfile.gold}%`}} className="bg-yellow-400 h-full" title={`Gold/Alts: ${currentProfile.gold}%`}></div>
                </div>
                
                <div className="flex justify-between text-xs mb-8 text-gray-300">
                  <span className="flex items-center"><span className="w-2 h-2 bg-finOrange rounded-full mr-1"></span> Equity ({currentProfile.equity}%)</span>
                  <span className="flex items-center"><span className="w-2 h-2 bg-blue-400 rounded-full mr-1"></span> Debt ({currentProfile.debt}%)</span>
                  <span className="flex items-center"><span className="w-2 h-2 bg-yellow-400 rounded-full mr-1"></span> Gold ({currentProfile.gold}%)</span>
                </div>

                <div className="space-y-4 pt-6 border-t border-white/20">
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-400">Est. CAGR (Historical)</span>
                    <span className="font-bold text-finOrange">{currentProfile.return}% p.a.</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-400">Wealth Gained</span>
                    <span className="font-bold text-green-400">+{formatINR(wealthGained)}</span>
                  </div>
                  <div className="pt-4">
                    <p className="text-gray-400 text-xs uppercase tracking-widest mb-1">Projected Future Value</p>
                    <p className="text-4xl font-extrabold text-white">{formatINR(projectedWealth)}</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 4. NEW: Wealth Offerings (Dynamic Tabs) */}
      <section className="py-24 bg-slate-50 border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-finBlue mb-4">Our Investment Offerings</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">Comprehensive financial products structured to navigate market cycles and preserve capital.</p>
          </div>

          <div className="max-w-5xl mx-auto bg-white border border-gray-200 rounded-2xl overflow-hidden shadow-sm">
            <div className="flex flex-wrap md:flex-nowrap border-b border-gray-200 bg-slate-50">
              {Object.keys(offerings).map((key) => (
                <button 
                  key={key}
                  onClick={() => setActiveTab(key)}
                  className={`flex-1 py-4 px-2 text-center font-bold text-sm md:text-base transition-colors flex flex-col md:flex-row items-center justify-center gap-2 ${activeTab === key ? 'border-b-4 border-finOrange text-finBlue bg-white' : 'text-gray-500 hover:bg-gray-100 border-b-4 border-transparent'}`}
                >
                  {offerings[key].icon} {offerings[key].title}
                </button>
              ))}
            </div>

            <div className="p-8 md:p-12">
              <div className="flex items-center mb-6">
                <div className="p-4 bg-finOrange/10 rounded-xl text-finOrange mr-6 hidden md:block">
                  {offerings[activeTab].icon}
                </div>
                <div>
                  <h3 className="text-2xl font-bold text-finBlue mb-2">{offerings[activeTab].title}</h3>
                  <p className="text-gray-600 leading-relaxed">{offerings[activeTab].desc}</p>
                </div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-8 pt-8 border-t border-gray-100">
                {offerings[activeTab].points.map((point, i) => (
                  <div key={i} className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-finOrange mt-0.5 mr-3 flex-shrink-0" />
                    <span className="text-gray-700 font-medium">{point}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 5. AIF / Global Funds Split (From Original) */}
      <section className="py-24 bg-white border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <span className="text-finOrange font-bold tracking-wider uppercase text-sm mb-4 block">Exclusive Structures</span>
            <h2 className="text-3xl font-bold text-finBlue mb-4">Alternative Investment Funds (AIF)</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">Exclusive access to high-yield, structured fund opportunities across global and domestic markets.</p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {/* Outbound Funds */}
            <div className="bg-finBlue text-white rounded-3xl p-10 shadow-xl relative overflow-hidden group hover:shadow-2xl transition">
              <Globe className="absolute top-0 right-0 w-48 h-48 text-white opacity-5 -mt-8 -mr-8 group-hover:scale-110 transition duration-700" />
              <div className="relative z-10">
                <h3 className="text-2xl font-bold mb-4 flex items-center">
                  <Globe className="w-6 h-6 text-finOrange mr-3" />
                  Outbound Funds
                </h3>
                <p className="text-gray-300 mb-8 leading-relaxed">Tap into Global Growth Themes with our Category III Close-Ended AIF structures. Access tech monoliths and emerging global sectors.</p>
                <div className="space-y-4">
                  <p className="font-semibold text-finOrange uppercase text-sm tracking-wider">Exposure Themes:</p>
                  <div className="flex flex-wrap gap-2 mb-6">
                    {['Semiconductors', 'Defence Tech', 'Disruptive Materials', 'AI', 'Blockchain'].map((tag, i) => (
                      <span key={i} className="bg-white/10 px-3 py-1 rounded-full text-sm border border-white/20 backdrop-blur-sm">{tag}</span>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            {/* Inbound Funds */}
            <div className="bg-slate-50 border border-gray-200 rounded-3xl p-10 shadow-sm relative overflow-hidden group hover:shadow-lg transition">
              <TrendingUp className="absolute top-0 right-0 w-48 h-48 text-finBlue opacity-5 -mt-8 -mr-8 group-hover:scale-110 transition duration-700" />
              <div className="relative z-10">
                <h3 className="text-2xl font-bold text-finBlue mb-4 flex items-center">
                  <TrendingUp className="w-6 h-6 text-finBlue mr-3" />
                  Inbound Funds
                </h3>
                <p className="text-gray-600 mb-8 leading-relaxed">Participate directly in the India Growth Story through our Category III Open-Ended AIFs. Optimized for foreign and NRI capital.</p>
                <div className="space-y-4">
                  <p className="font-semibold text-finBlue uppercase text-sm tracking-wider">Target Investors:</p>
                  <div className="flex flex-wrap gap-2 mb-6">
                    {['NRIs', 'Foreign Corporates', 'Domestic HNIs', 'Family Offices'].map((tag, i) => (
                      <span key={i} className="bg-finBlue/5 text-finBlue px-3 py-1 rounded-full text-sm border border-finBlue/10">{tag}</span>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 6. Professional Credentials Section */}
      <section className="py-20 bg-slate-900 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold mb-4">Certified & Regulated Expertise</h2>
            <p className="text-gray-400 max-w-2xl mx-auto">
              Your wealth is managed by highly qualified professionals holding rigorous regulatory certifications.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              { title: "NISM Series V-A", desc: "Certified Mutual Fund Distributors for optimal scheme selection.", icon: <Award className="w-8 h-8 text-finOrange" /> },
              { title: "NISM Series XXI-A", desc: "Specialized in Portfolio Management Services (PMS).", icon: <Briefcase className="w-8 h-8 text-finOrange" /> },
              { title: "NISM Series XIII", desc: "Certified expertise in the derivatives market for risk management.", icon: <TrendingUp className="w-8 h-8 text-finOrange" /> },
              { title: "RERA Certified", desc: "Registered real estate agents ensuring transparent property investments.", icon: <Building2 className="w-8 h-8 text-finOrange" /> }
            ].map((cert, index) => (
              <div key={index} className="bg-white/5 p-8 rounded-2xl border border-white/10 hover:bg-white/10 transition duration-300 text-center">
                <div className="bg-white/10 w-16 h-16 rounded-full flex items-center justify-center mb-6 mx-auto">
                  {cert.icon}
                </div>
                <h3 className="text-lg font-bold mb-2">{cert.title}</h3>
                <p className="text-sm text-gray-400">{cert.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 7. FAQ Accordion */}
      <section className="py-24 bg-slate-50 border-b border-gray-100">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-finBlue mb-4">Frequently Asked Questions</h2>
            <p className="text-gray-600">Clarity on our wealth management processes.</p>
          </div>
          <div className="space-y-4">
            {faqs.map((faq, index) => (
              <div key={index} className="bg-white border border-gray-200 rounded-lg overflow-hidden transition-all duration-300 shadow-sm">
                <button 
                  onClick={() => setActiveFaq(activeFaq === index ? null : index)}
                  className="w-full flex justify-between items-center p-6 hover:bg-gray-50 transition text-left"
                >
                  <span className="font-bold text-finBlue text-lg pr-4">{faq.question}</span>
                  {activeFaq === index ? <ChevronUp className="w-5 h-5 text-finOrange flex-shrink-0" /> : <ChevronDown className="w-5 h-5 text-gray-400 flex-shrink-0" />}
                </button>
                <div className={`px-6 overflow-hidden transition-all duration-300 ${activeFaq === index ? 'max-h-40 py-6 border-t border-gray-100' : 'max-h-0 py-0'}`}>
                  <p className="text-gray-600 leading-relaxed">{faq.answer}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 8. Lead Magnet: Market Outlook PDF */}
      <section className="py-16 bg-white">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-finBlue rounded-3xl p-8 md:p-12 flex flex-col md:flex-row items-center justify-between gap-8 shadow-2xl relative overflow-hidden">
            <Landmark className="absolute top-0 right-0 w-64 h-64 text-white opacity-5 -mr-10 -mt-10" />
            <div className="flex-1 text-center md:text-left relative z-10">
              <h3 className="text-2xl font-bold text-white mb-2">Get Our Q3 Market Strategy Report</h3>
              <p className="text-gray-300">Subscribe to our HNI newsletter to receive exclusive insights on upcoming AIF launches, market valuations, and asset allocation strategies.</p>
            </div>
            <div className="w-full md:w-auto flex-shrink-0 relative z-10">
              <form className="flex w-full shadow-lg" onSubmit={(e) => e.preventDefault()}>
                <input 
                  type="email" 
                  placeholder="Your Email Address" 
                  className="w-full md:w-64 px-4 py-4 rounded-l-lg border-none focus:outline-none focus:ring-2 focus:ring-finOrange text-gray-800"
                />
                <button className="bg-finOrange hover:bg-finOrange-dark text-white px-6 py-4 rounded-r-lg font-bold transition flex items-center whitespace-nowrap">
                  <Mail className="w-5 h-5 mr-2" /> Subscribe
                </button>
              </form>
            </div>
          </div>
        </div>
      </section>

    </div>
  );
};

export default InvestmentServices;