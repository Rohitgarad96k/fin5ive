import React, { useState } from 'react';
import { 
  MapPin, Phone, Mail, Clock, Send, Building2, 
  Globe, MessageSquare, ArrowRight, CheckCircle, 
  MessageCircle, Map, Loader2,
  ChevronDown,
  ShieldCheck
} from 'lucide-react';
import toast from 'react-hot-toast';

const Contact = () => {
  // --- STATE MANAGEMENT ---
  const [activeLocation, setActiveLocation] = useState('MUMBAI');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [formErrors, setFormErrors] = useState({});

  // Form Data State
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    company: '',
    service: '',
    message: ''
  });

  // --- LOCATION DATA (Fully Functional Links) ---
  const locations = {
    MUMBAI: {
      type: "Corporate Headquarters",
      building: "Financial District, BKC",
      address: "Bandra Kurla Complex, Mumbai, Maharashtra 400051",
      phone: "+91 22 4567 8900",
      phoneLink: "+912245678900",
      email: "bkc@fin5ive.com",
      whatsapp: "919876543210", // Use country code without +
      mapUrl: "https://www.google.com/maps/search/?api=1&query=Bandra+Kurla+Complex+Mumbai"
    },
    GIFTCITY: {
      type: "Offshore & Global Desk",
      building: "GIFT SEZ Financial Centre",
      address: "GIFT City, Gandhinagar, Gujarat 382355",
      phone: "+91 79 1234 5678",
      phoneLink: "+917912345678",
      email: "ifsc@fin5ive.com",
      whatsapp: "919876543211",
      mapUrl: "https://www.google.com/maps/search/?api=1&query=GIFT+City+Gandhinagar"
    }
  };

  // --- FORM HANDLING & VALIDATION ---
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
    // Clear error when user starts typing
    if (formErrors[name]) {
      setFormErrors({ ...formErrors, [name]: null });
    }
  };

  const validateForm = () => {
    const errors = {};
    if (!formData.name.trim()) errors.name = "Name is required";
    if (!formData.email.match(/^[^\s@]+@[^\s@]+\.[^\s@]+$/)) errors.email = "Valid email is required";
    if (!formData.phone.match(/^\+?[0-9\s-]{10,15}$/)) errors.phone = "Valid phone number is required";
    if (!formData.service) errors.service = "Please select a service";
    if (!formData.message.trim()) errors.message = "Please provide a brief message";
    return errors;
  };

  const handleFormSubmit = (e) => {
  e.preventDefault();
  const errors = validateForm();

  if (Object.keys(errors).length > 0) {
    setFormErrors(errors);
    // Add an error toast
    toast.error("Please fix the errors in the form.", {
      style: {
        border: '1px solid #EF4444',
        padding: '16px',
        color: '#713200',
      },
      iconTheme: {
        primary: '#EF4444',
        secondary: '#FFFAEE',
      },
    });
    return;
  }

  setIsSubmitting(true);

  // Simulate API call
  const promise = new Promise((resolve) => setTimeout(resolve, 2000));

  toast.promise(promise, {
    loading: 'Securely transmitting data...',
    success: 'Inquiry received! We will contact you shortly.',
    error: 'Transmission failed. Please try again.',
  }, {
    style: {
      minWidth: '250px',
      fontWeight: 'bold',
    },
    success: {
      duration: 5000,
      iconTheme: {
        primary: '#10B981', // Green-500
        secondary: 'white',
      },
    },
  });

  promise.then(() => {
    setIsSubmitting(false);
    setIsSubmitted(true);
    setFormData({ name: '', email: '', phone: '', company: '', service: '', message: '' });
    setTimeout(() => setIsSubmitted(false), 6000);
  });
};

  return (
    <div className="bg-white overflow-hidden">
      
      {/* 1. Hero Section */}
      <div className="bg-finBlue text-white py-24 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-1/2 h-full bg-gradient-to-l from-finBlue-light/50 to-transparent"></div>
        <Globe className="absolute top-10 -right-20 w-96 h-96 text-white opacity-5 animate-[spin_120s_linear_infinite] pointer-events-none" />
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center">
          <div className="inline-flex items-center justify-center space-x-2 text-finOrange font-bold tracking-wider uppercase text-sm mb-6">
            <MessageSquare className="w-5 h-5" />
            <span>Get In Touch</span>
          </div>
          <h1 className="text-4xl md:text-6xl font-extrabold mb-6 leading-tight max-w-4xl mx-auto">
            Let's Architect Your <br/><span className="text-finOrange">Financial Future.</span>
          </h1>
          <p className="text-xl text-gray-300 max-w-2xl mx-auto">
            Whether you are planning an IPO, expanding to GIFT City, or seeking bespoke wealth management, our leadership team is ready to listen.
          </p>
        </div>
      </div>

      {/* 2. Main Contact Section (Grid) */}
      <section className="py-24 bg-slate-50 border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16">
            
            {/* Left Side: Dynamic Contact Info & Locations */}
            <div className="lg:col-span-5">
              
              {/* Dynamic Office Locations Tabs */}
              <div className="bg-white rounded-3xl border border-gray-200 overflow-hidden shadow-md mb-8">
                <div className="flex border-b border-gray-200 bg-slate-50">
                  {Object.keys(locations).map((key) => (
                    <button 
                      key={key}
                      onClick={() => setActiveLocation(key)}
                      className={`flex-1 py-5 text-center font-bold text-sm transition-colors flex items-center justify-center ${activeLocation === key ? 'border-b-4 border-finOrange text-finBlue bg-white' : 'text-gray-400 hover:bg-gray-100 border-b-4 border-transparent'}`}
                    >
                      <Building2 className={`w-4 h-4 mr-2 ${activeLocation === key ? 'text-finOrange' : 'text-gray-400'}`} />
                      {key === 'MUMBAI' ? 'Mumbai HQ' : 'GIFT City'}
                    </button>
                  ))}
                </div>
                
                {/* Active Office Details */}
                <div className="p-8 transition-all duration-300">
                  <p className="text-finOrange font-bold text-sm uppercase tracking-widest mb-2">{locations[activeLocation].type}</p>
                  <p className="text-2xl font-bold text-finBlue mb-4">{locations[activeLocation].building}</p>
                  
                  <div className="flex items-start mb-6">
                    <MapPin className="w-5 h-5 text-gray-400 mr-3 flex-shrink-0 mt-0.5" />
                    <p className="text-gray-600 leading-relaxed">{locations[activeLocation].address}</p>
                  </div>

                  <a href={locations[activeLocation].mapUrl} target="_blank" rel="noopener noreferrer" className="inline-flex items-center text-sm font-bold text-finBlue hover:text-finOrange transition-colors bg-slate-50 px-4 py-2 rounded-lg border border-gray-200">
                    <Map className="w-4 h-4 mr-2" /> Get Directions
                  </a>
                </div>
              </div>

              {/* Dynamic Quick Contact Cards (Values change based on active tab) */}
              <h3 className="text-xl font-bold text-finBlue mb-4">Direct Contact</h3>
              <div className="space-y-4">
                <a href={`mailto:${locations[activeLocation].email}?subject=Corporate Inquiry`} className="flex items-center p-5 bg-white rounded-2xl border border-gray-200 shadow-sm hover:border-finOrange hover:shadow-md transition-all group">
                  <div className="bg-orange-50 p-4 rounded-xl text-finOrange mr-5 group-hover:scale-110 transition-transform">
                    <Mail className="w-6 h-6" />
                  </div>
                  <div>
                    <p className="text-sm text-gray-500 font-bold uppercase tracking-wider mb-1">Email Desk</p>
                    <p className="text-lg font-bold text-finBlue">{locations[activeLocation].email}</p>
                  </div>
                </a>
                
                <a href={`tel:${locations[activeLocation].phoneLink}`} className="flex items-center p-5 bg-white rounded-2xl border border-gray-200 shadow-sm hover:border-finBlue hover:shadow-md transition-all group">
                  <div className="bg-blue-50 p-4 rounded-xl text-finBlue mr-5 group-hover:scale-110 transition-transform">
                    <Phone className="w-6 h-6" />
                  </div>
                  <div>
                    <p className="text-sm text-gray-500 font-bold uppercase tracking-wider mb-1">Call Office</p>
                    <p className="text-lg font-bold text-finBlue">{locations[activeLocation].phone}</p>
                  </div>
                </a>

                <a href={`https://wa.me/${locations[activeLocation].whatsapp}?text=Hello%20FIN5IVE,%20I%20would%20like%20to%20discuss%20financial%20advisory%20services.`} target="_blank" rel="noopener noreferrer" className="flex items-center p-5 bg-white rounded-2xl border border-gray-200 shadow-sm hover:border-green-500 hover:shadow-md transition-all group">
                  <div className="bg-green-50 p-4 rounded-xl text-green-600 mr-5 group-hover:scale-110 transition-transform">
                    <MessageCircle className="w-6 h-6" />
                  </div>
                  <div>
                    <p className="text-sm text-gray-500 font-bold uppercase tracking-wider mb-1">WhatsApp Chat</p>
                    <p className="text-lg font-bold text-gray-800">Instant Connect</p>
                  </div>
                </a>
              </div>

            </div>

            {/* Right Side: Smart Contact Form */}
            <div className="lg:col-span-7">
              <div className="bg-white p-8 md:p-12 rounded-3xl shadow-xl border border-gray-100 relative overflow-hidden">
                {/* Decorative background element inside form */}
                <div className="absolute top-0 right-0 w-32 h-32 bg-finOrange opacity-5 rounded-bl-full pointer-events-none"></div>

                <h2 className="text-2xl font-bold text-finBlue mb-2">Request a Strategy Session</h2>
                <p className="text-gray-500 mb-8">Fill out the form below. Your inquiry will be routed securely to the relevant department head.</p>

                {isSubmitted ? (
                  <div className="bg-green-50 border border-green-200 rounded-2xl p-10 text-center animate-[fadeIn_0.5s_ease-in]">
                    <CheckCircle className="w-20 h-20 text-green-500 mx-auto mb-6" />
                    <h3 className="text-2xl font-bold text-green-800 mb-2">Inquiry Received Successfully!</h3>
                    <p className="text-green-700">Thank you for reaching out. A senior partner from our advisory team will contact you within 24 business hours.</p>
                  </div>
                ) : (
                  <form onSubmit={handleFormSubmit} className="space-y-5">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                      <div>
                        <label className="block text-sm font-bold text-gray-700 mb-2">Full Name <span className="text-red-500">*</span></label>
                        <input 
                          type="text" name="name" value={formData.name} onChange={handleInputChange}
                          className={`w-full bg-slate-50 border ${formErrors.name ? 'border-red-500' : 'border-gray-200'} rounded-xl px-5 py-4 focus:ring-2 focus:ring-finOrange focus:bg-white outline-none transition-all`} 
                          placeholder="John Doe" 
                        />
                        {formErrors.name && <p className="text-red-500 text-xs mt-1">{formErrors.name}</p>}
                      </div>
                      <div>
                        <label className="block text-sm font-bold text-gray-700 mb-2">Corporate Email <span className="text-red-500">*</span></label>
                        <input 
                          type="email" name="email" value={formData.email} onChange={handleInputChange}
                          className={`w-full bg-slate-50 border ${formErrors.email ? 'border-red-500' : 'border-gray-200'} rounded-xl px-5 py-4 focus:ring-2 focus:ring-finOrange focus:bg-white outline-none transition-all`} 
                          placeholder="john@company.com" 
                        />
                        {formErrors.email && <p className="text-red-500 text-xs mt-1">{formErrors.email}</p>}
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                      <div>
                        <label className="block text-sm font-bold text-gray-700 mb-2">Phone Number <span className="text-red-500">*</span></label>
                        <input 
                          type="tel" name="phone" value={formData.phone} onChange={handleInputChange}
                          className={`w-full bg-slate-50 border ${formErrors.phone ? 'border-red-500' : 'border-gray-200'} rounded-xl px-5 py-4 focus:ring-2 focus:ring-finOrange focus:bg-white outline-none transition-all`} 
                          placeholder="+91 98765 43210" 
                        />
                        {formErrors.phone && <p className="text-red-500 text-xs mt-1">{formErrors.phone}</p>}
                      </div>
                      <div>
                        <label className="block text-sm font-bold text-gray-700 mb-2">Company / Organization</label>
                        <input 
                          type="text" name="company" value={formData.company} onChange={handleInputChange}
                          className="w-full bg-slate-50 border border-gray-200 rounded-xl px-5 py-4 focus:ring-2 focus:ring-finOrange focus:bg-white outline-none transition-all" 
                          placeholder="Acme Corp Ltd." 
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-sm font-bold text-gray-700 mb-2">Service Required <span className="text-red-500">*</span></label>
                      <div className="relative">
                        <select 
                          name="service" value={formData.service} onChange={handleInputChange}
                          className={`w-full bg-slate-50 border ${formErrors.service ? 'border-red-500' : 'border-gray-200'} rounded-xl px-5 py-4 focus:ring-2 focus:ring-finOrange focus:bg-white outline-none transition-all appearance-none`}
                        >
                          <option value="" disabled>Select an advisory service...</option>
                          <option>Capital Markets (IPO Advisory)</option>
                          <option>GIFT City IFSC Setup</option>
                          <option>Corporate Working Capital</option>
                          <option>Cross-Border Trade Finance</option>
                          <option>HNI Wealth Management</option>
                          <option>NRI Financial Services</option>
                          <option>ZED Certification & Subsidies</option>
                          <option>General Inquiry</option>
                        </select>
                        <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-5 text-gray-500">
                          <ChevronDown className="w-5 h-5" />
                        </div>
                      </div>
                      {formErrors.service && <p className="text-red-500 text-xs mt-1">{formErrors.service}</p>}
                    </div>

                    <div>
                      <label className="block text-sm font-bold text-gray-700 mb-2">Your Message <span className="text-red-500">*</span></label>
                      <textarea 
                        rows="3" name="message" value={formData.message} onChange={handleInputChange}
                        className={`w-full bg-slate-50 border ${formErrors.message ? 'border-red-500' : 'border-gray-200'} rounded-xl px-5 py-4 focus:ring-2 focus:ring-finOrange focus:bg-white outline-none transition-all resize-none`} 
                        placeholder="Please briefly describe your current financial requirement..."
                      ></textarea>
                      {formErrors.message && <p className="text-red-500 text-xs mt-1">{formErrors.message}</p>}
                    </div>

                    <button 
                      type="submit" disabled={isSubmitting}
                      className={`w-full text-white font-bold py-4 rounded-xl transition-all duration-300 shadow-lg flex justify-center items-center text-lg ${isSubmitting ? 'bg-gray-400 cursor-not-allowed' : 'bg-finBlue hover:bg-finBlue-light group'}`}
                    >
                      {isSubmitting ? (
                        <><Loader2 className="w-6 h-6 mr-2 animate-spin" /> Submitting securely...</>
                      ) : (
                        <>Send Secure Message <Send className="w-5 h-5 ml-3 group-hover:translate-x-1 transition-transform" /></>
                      )}
                    </button>
                    <p className="text-center text-xs text-gray-400 mt-4 flex items-center justify-center">
                      <ShieldCheck className="w-4 h-4 mr-1" /> Your information is protected by standard NDA policies.
                    </p>
                  </form>
                )}
              </div>
            </div>

          </div>
        </div>
      </section>

      {/* 3. "What Happens Next" Timeline */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <span className="text-finOrange font-bold tracking-wider uppercase text-sm mb-4 block">Our Process</span>
            <h2 className="text-3xl font-bold text-finBlue mb-4">What Happens After You Contact Us?</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">We value your time. Our onboarding process is designed to be swift, professional, and entirely focused on execution.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            {[
              { step: 1, title: "Review", desc: "Your inquiry is instantly routed to the specific department head (IPO, Wealth, MSME)." },
              { step: 2, title: "Initial Call", desc: "A senior partner contacts you within 24 hours to understand your exact requirements." },
              { step: 3, title: "NDA & Discovery", desc: "We sign a Non-Disclosure Agreement before deep-diving into your financials." },
              { step: 4, title: "Strategy Blueprint", desc: "We present a customized execution plan detailing timelines, costs, and outcomes." }
            ].map((item, i) => (
              <div key={i} className="relative p-8 bg-slate-50 rounded-2xl border border-gray-100 hover:border-finOrange transition duration-300 shadow-sm hover:shadow-md">
                <div className="w-12 h-12 bg-finOrange rounded-full flex items-center justify-center font-bold text-white mb-6 shadow-md">
                  {item.step}
                </div>
                <h4 className="font-bold text-xl text-finBlue mb-3">{item.title}</h4>
                <p className="text-gray-600 text-sm leading-relaxed">{item.desc}</p>
                {/* Visual connecting arrow (hidden on mobile, hidden on last item) */}
                {i !== 3 && (
                  <ArrowRight className="hidden md:block absolute top-12 -right-6 w-8 h-8 text-gray-300" />
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 4. Business Hours Footer Block */}
      <section className="bg-finBlue py-12 border-t-4 border-finOrange">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row items-center justify-between">
            <div className="flex items-center mb-6 md:mb-0">
              <div className="bg-white/10 p-4 rounded-full mr-6">
                <Clock className="w-8 h-8 text-finOrange" />
              </div>
              <div>
                <h3 className="text-2xl font-bold text-white mb-1">Standard Business Hours</h3>
                <p className="text-gray-400">Monday - Friday: 9:30 AM to 6:30 PM (IST)</p>
              </div>
            </div>
            <div className="text-center md:text-right">
              <p className="text-gray-300 mb-2">Need immediate assistance for urgent corporate transactions?</p>
              <a href="mailto:director@fin5ive.com" className="text-finOrange font-bold hover:text-white transition-colors border-b border-finOrange hover:border-white pb-1">
                Email the Director's Office directly
              </a>
            </div>
          </div>
        </div>
      </section>

    </div>
  );
};

export default Contact;