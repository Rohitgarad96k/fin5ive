import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { 
  Lock, Mail, Key, ShieldCheck, ArrowLeft, Loader2, Server, 
  LayoutDashboard, Briefcase, FileText, Settings, LogOut, 
  TrendingUp, Download, Bell, User as UserIcon, Activity, CheckCircle
} from 'lucide-react';
import toast from 'react-hot-toast';

const ClientPortal = () => {
  // --- AUTHENTICATION STATE ---
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [view, setView] = useState('LOGIN'); // LOGIN, FORGOT_PASSWORD

  // --- LOGIN FORM STATE ---
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  // --- DASHBOARD STATE ---
  const [activeTab, setActiveTab] = useState('OVERVIEW'); // OVERVIEW, PORTFOLIO, DOCUMENTS

  // --- HANDLERS ---
  const handleLogin = (e) => {
    e.preventDefault();
    if (!email || !password) {
      toast.error("Please enter both email and password.");
      return;
    }

    setIsSubmitting(true);

    // Simulate Secure Authentication (Accepts any input for demo purposes)
    setTimeout(() => {
      setIsSubmitting(false);
      setIsLoggedIn(true);
      toast.success('Authentication successful. Welcome back!', {
        iconTheme: { primary: '#10B981', secondary: 'white' }
      });
    }, 1500);
  };

  const handleResetPassword = (e) => {
    e.preventDefault();
    if (!email) {
      toast.error("Please enter your registered email address.");
      return;
    }
    setIsSubmitting(true);
    setTimeout(() => {
      setIsSubmitting(false);
      setView('LOGIN');
      toast.success('Password reset link sent to your corporate email.');
    }, 1500);
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
    setEmail('');
    setPassword('');
    setView('LOGIN');
    toast('Securely logged out.', { icon: '🔒' });
  };

  const formatINR = (value) => new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(value);

  // ==========================================
  // RENDER: SECURE DASHBOARD (POST-LOGIN)
  // ==========================================
  if (isLoggedIn) {
    return (
      <div className="min-h-screen bg-slate-50 flex flex-col md:flex-row relative z-[60]">
        
        {/* Sidebar Navigation */}
        <aside className="w-full md:w-64 bg-finBlue text-white flex flex-col shadow-2xl z-20 md:min-h-screen">
          <div className="p-6 border-b border-white/10 flex items-center justify-between">
            <Link to="/" className="flex flex-col">
              <span className="text-2xl font-black tracking-tighter text-white leading-none">
                FIN<span className="text-finOrange">5</span>IVE
              </span>
              <span className="text-[0.55rem] font-bold text-finOrange tracking-[0.2em] uppercase mt-1">
                Client Portal
              </span>
            </Link>
          </div>
          
          <nav className="flex-1 px-4 py-6 space-y-2 overflow-x-auto md:overflow-visible flex md:block whitespace-nowrap">
            <button onClick={() => setActiveTab('OVERVIEW')} className={`flex items-center w-full md:w-auto px-4 py-3 rounded-lg font-medium transition-colors ${activeTab === 'OVERVIEW' ? 'bg-finOrange text-white' : 'text-gray-300 hover:bg-white/5 hover:text-white'}`}>
              <LayoutDashboard className="w-5 h-5 mr-3" /> Overview
            </button>
            <button onClick={() => setActiveTab('PORTFOLIO')} className={`flex items-center w-full md:w-auto px-4 py-3 rounded-lg font-medium transition-colors ${activeTab === 'PORTFOLIO' ? 'bg-finOrange text-white' : 'text-gray-300 hover:bg-white/5 hover:text-white'}`}>
              <Briefcase className="w-5 h-5 mr-3" /> Wealth Portfolio
            </button>
            <button onClick={() => setActiveTab('DOCUMENTS')} className={`flex items-center w-full md:w-auto px-4 py-3 rounded-lg font-medium transition-colors ${activeTab === 'DOCUMENTS' ? 'bg-finOrange text-white' : 'text-gray-300 hover:bg-white/5 hover:text-white'}`}>
              <FileText className="w-5 h-5 mr-3" /> Document Vault
            </button>
            <button className="flex items-center w-full md:w-auto px-4 py-3 rounded-lg font-medium text-gray-300 hover:bg-white/5 hover:text-white transition-colors">
              <Settings className="w-5 h-5 mr-3" /> Settings
            </button>
          </nav>

          <div className="p-4 border-t border-white/10">
            <button onClick={handleLogout} className="flex items-center w-full px-4 py-3 rounded-lg font-medium text-red-400 hover:bg-red-400/10 transition-colors">
              <LogOut className="w-5 h-5 mr-3" /> Secure Logout
            </button>
          </div>
        </aside>

        {/* Main Content Area */}
        <main className="flex-1 flex flex-col h-screen overflow-y-auto">
          {/* Top Header */}
          <header className="bg-white border-b border-gray-200 px-8 py-4 flex justify-between items-center sticky top-0 z-10">
            <div>
              <h2 className="text-xl font-bold text-finBlue hidden sm:block">Welcome back, Director</h2>
            </div>
            <div className="flex items-center space-x-4">
              <button className="relative p-2 text-gray-400 hover:text-finBlue transition-colors">
                <Bell className="w-6 h-6" />
                <span className="absolute top-1 right-1 w-2.5 h-2.5 bg-red-500 rounded-full border-2 border-white"></span>
              </button>
              <div className="flex items-center space-x-3 pl-4 border-l border-gray-200">
                <div className="text-right hidden sm:block">
                  <p className="text-sm font-bold text-finBlue leading-tight">{email || "Client"}</p>
                  <p className="text-xs text-gray-500">Corporate Account</p>
                </div>
                <div className="w-10 h-10 bg-slate-100 rounded-full flex items-center justify-center border border-gray-200">
                  <UserIcon className="w-5 h-5 text-finBlue" />
                </div>
              </div>
            </div>
          </header>

          {/* Dashboard Body */}
          <div className="p-8">
            
            {/* --- OVERVIEW TAB --- */}
            {activeTab === 'OVERVIEW' && (
              <div className="animate-[fadeIn_0.3s_ease-out]">
                {/* Metrics Grid */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                  <div className="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm flex flex-col justify-between">
                    <div className="flex justify-between items-start mb-4">
                      <p className="text-sm font-bold text-gray-500 uppercase tracking-widest">Active Working Capital</p>
                      <div className="bg-blue-50 p-2 rounded-lg text-finBlue"><Activity className="w-5 h-5" /></div>
                    </div>
                    <div>
                      <h3 className="text-3xl font-extrabold text-finBlue">{formatINR(15000000)}</h3>
                      <p className="text-sm text-green-500 font-medium mt-2 flex items-center"><CheckCircle className="w-4 h-4 mr-1"/> Limit active & healthy</p>
                    </div>
                  </div>

                  <div className="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm flex flex-col justify-between">
                    <div className="flex justify-between items-start mb-4">
                      <p className="text-sm font-bold text-gray-500 uppercase tracking-widest">Total Wealth AUM</p>
                      <div className="bg-orange-50 p-2 rounded-lg text-finOrange"><TrendingUp className="w-5 h-5" /></div>
                    </div>
                    <div>
                      <h3 className="text-3xl font-extrabold text-finBlue">{formatINR(42500000)}</h3>
                      <p className="text-sm text-green-500 font-medium mt-2 flex items-center"><TrendingUp className="w-4 h-4 mr-1"/> +12.4% YTD Returns</p>
                    </div>
                  </div>

                  <div className="bg-finBlue p-6 rounded-2xl shadow-lg flex flex-col justify-between text-white relative overflow-hidden">
                    <Server className="absolute -bottom-4 -right-4 w-24 h-24 opacity-10" />
                    <div className="relative z-10">
                      <p className="text-sm font-bold text-finOrange uppercase tracking-widest mb-4">IPO Preparation Status</p>
                      <h3 className="text-3xl font-extrabold mb-2">Phase 2</h3>
                      <p className="text-sm text-gray-300 mb-4">DRHP Drafting in progress</p>
                      <div className="w-full bg-white/20 rounded-full h-2">
                        <div className="bg-finOrange h-2 rounded-full" style={{width: '45%'}}></div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Recent Activity */}
                <h3 className="text-lg font-bold text-finBlue mb-4">Recent Transactions & Updates</h3>
                <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
                  {[
                    { title: "Monthly Interest Debited (CC A/c)", date: "Today, 10:00 AM", amt: "- ₹1,25,000", status: "Processed" },
                    { title: "Mutual Fund SIP Executed", date: "Yesterday, 09:30 AM", amt: "₹5,00,000", status: "Invested" },
                    { title: "ZED Certification Audit Cleared", date: "Oct 12, 2024", amt: "N/A", status: "Approved", isGreen: true },
                    { title: "Form 15CA/CB Issued for Repatriation", date: "Oct 05, 2024", amt: "$50,000", status: "Completed" }
                  ].map((item, i) => (
                    <div key={i} className="flex justify-between items-center p-5 border-b border-gray-50 hover:bg-slate-50 transition-colors">
                      <div>
                        <p className="font-bold text-finBlue">{item.title}</p>
                        <p className="text-xs text-gray-500 mt-1">{item.date}</p>
                      </div>
                      <div className="text-right">
                        <p className={`font-bold ${item.isGreen ? 'text-green-500' : 'text-gray-800'}`}>{item.amt}</p>
                        <p className="text-xs text-finOrange font-medium uppercase mt-1">{item.status}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* --- DOCUMENTS TAB --- */}
            {activeTab === 'DOCUMENTS' && (
              <div className="animate-[fadeIn_0.3s_ease-out]">
                <div className="flex justify-between items-center mb-6">
                  <h3 className="text-xl font-bold text-finBlue">Secure Document Vault</h3>
                  <button className="bg-finBlue hover:bg-finBlue-light text-white px-4 py-2 rounded-lg text-sm font-bold transition">Upload File</button>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {[
                    { name: "Q2 FY25 Portfolio Valuation Report.pdf", size: "1.2 MB", date: "Nov 01, 2024" },
                    { name: "HDFC Bank CC Sanction Letter.pdf", size: "3.5 MB", date: "Sep 15, 2024" },
                    { name: "Form 15CB - CA Certificate.pdf", size: "800 KB", date: "Oct 05, 2024" },
                    { name: "ZED Gold Certificate.pdf", size: "2.1 MB", date: "Oct 12, 2024" }
                  ].map((doc, i) => (
                    <div key={i} className="bg-white p-5 rounded-2xl border border-gray-100 shadow-sm flex items-center justify-between group hover:border-finOrange transition">
                      <div className="flex items-center">
                        <div className="bg-red-50 p-3 rounded-lg text-red-500 mr-4">
                          <FileText className="w-6 h-6" />
                        </div>
                        <div>
                          <p className="font-bold text-finBlue text-sm">{doc.name}</p>
                          <p className="text-xs text-gray-500 mt-1">{doc.size} • Uploaded {doc.date}</p>
                        </div>
                      </div>
                      <button className="text-gray-400 group-hover:text-finOrange transition p-2">
                        <Download className="w-5 h-5" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* PORTFOLIO TAB (Placeholder) */}
            {activeTab === 'PORTFOLIO' && (
              <div className="animate-[fadeIn_0.3s_ease-out] text-center py-20">
                <Briefcase className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                <h3 className="text-2xl font-bold text-finBlue mb-2">Portfolio Analytics Syncing</h3>
                <p className="text-gray-500">Your Demat and AIF holding data is currently being fetched securely from the exchange.</p>
              </div>
            )}

          </div>
        </main>
      </div>
    );
  }

  // ==========================================
  // RENDER: LOGIN & AUTHENTICATION SCREEN
  // ==========================================
  return (
    <div className="min-h-[90vh] flex bg-white relative z-50">
      
      {/* Left Side: Security & Branding (Hidden on small mobile) */}
      <div className="hidden lg:flex lg:w-1/2 bg-finBlue text-white p-12 flex-col justify-between relative overflow-hidden">
        <Server className="absolute -bottom-20 -left-20 w-96 h-96 opacity-5 pointer-events-none" />
        
        <div className="relative z-10 max-w-lg mt-10">
          <ShieldCheck className="w-16 h-16 text-finOrange mb-8" />
          <h1 className="text-4xl md:text-5xl font-extrabold mb-6 leading-tight">
            Secure Client <span className="text-finOrange">Portal.</span>
          </h1>
          <p className="text-lg text-gray-300 mb-10 leading-relaxed">
            Access your investment portfolios, track IPO execution progress, and securely manage your cross-border documentation in one encrypted environment.
          </p>
          
          <div className="space-y-4">
            <div className="flex items-center text-sm text-gray-400">
              <Lock className="w-4 h-4 mr-3 text-finOrange" />
              256-bit AES Encryption
            </div>
            <div className="flex items-center text-sm text-gray-400">
              <ShieldCheck className="w-4 h-4 mr-3 text-finOrange" />
              Two-Factor Authentication (2FA) Ready
            </div>
          </div>
        </div>

        <div className="relative z-10">
          <p className="text-sm text-gray-500">© {new Date().getFullYear()} FIN5IVE Advisory. All rights reserved.</p>
        </div>
      </div>

      {/* Right Side: Dynamic Form Area */}
      <div className="w-full lg:w-1/2 flex items-center justify-center p-8 sm:p-12 relative">
        <div className="w-full max-w-md">
          
          {view === 'LOGIN' ? (
            <div className="animate-[fadeIn_0.3s_ease-out]">
              <div className="text-center mb-10">
                <h2 className="text-3xl font-bold text-finBlue mb-2">Welcome Back</h2>
                <p className="text-gray-500">Enter your credentials to access your secure dashboard.</p>
              </div>

              <form onSubmit={handleLogin} className="space-y-6">
                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-2">Corporate Email</label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                      <Mail className="h-5 w-5 text-gray-400" />
                    </div>
                    <input 
                      type="email" 
                      required
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="w-full bg-slate-50 border border-gray-200 rounded-xl py-4 pl-12 pr-4 focus:ring-2 focus:ring-finOrange focus:bg-white outline-none transition-all"
                      placeholder="director@company.com"
                    />
                  </div>
                </div>

                <div>
                  <div className="flex justify-between items-center mb-2">
                    <label className="block text-sm font-bold text-gray-700">Password</label>
                    <button type="button" onClick={() => setView('FORGOT_PASSWORD')} className="text-sm font-bold text-finOrange hover:text-finBlue transition-colors">Forgot password?</button>
                  </div>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                      <Key className="h-5 w-5 text-gray-400" />
                    </div>
                    <input 
                      type="password" 
                      required
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="w-full bg-slate-50 border border-gray-200 rounded-xl py-4 pl-12 pr-4 focus:ring-2 focus:ring-finOrange focus:bg-white outline-none transition-all"
                      placeholder="••••••••"
                    />
                  </div>
                </div>

                <button 
                  type="submit" 
                  disabled={isSubmitting}
                  className={`w-full text-white font-bold py-4 rounded-xl transition-all duration-300 shadow-lg flex justify-center items-center text-lg mt-4 ${isSubmitting ? 'bg-gray-400 cursor-not-allowed' : 'bg-finBlue hover:bg-finBlue-light'}`}
                >
                  {isSubmitting ? (
                    <><Loader2 className="w-6 h-6 mr-2 animate-spin" /> Authenticating...</>
                  ) : (
                    <>Secure Sign In</>
                  )}
                </button>
              </form>
            </div>
          ) : (
            <div className="animate-[fadeIn_0.3s_ease-out]">
              <div className="mb-6">
                <button onClick={() => setView('LOGIN')} className="flex items-center text-sm font-bold text-gray-500 hover:text-finBlue transition-colors">
                  <ArrowLeft className="w-4 h-4 mr-1" /> Back to Login
                </button>
              </div>
              <div className="text-center mb-10">
                <h2 className="text-3xl font-bold text-finBlue mb-2">Reset Password</h2>
                <p className="text-gray-500">Enter your registered email and we'll send you secure instructions to reset your password.</p>
              </div>

              <form onSubmit={handleResetPassword} className="space-y-6">
                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-2">Corporate Email</label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                      <Mail className="h-5 w-5 text-gray-400" />
                    </div>
                    <input 
                      type="email" 
                      required
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="w-full bg-slate-50 border border-gray-200 rounded-xl py-4 pl-12 pr-4 focus:ring-2 focus:ring-finOrange focus:bg-white outline-none transition-all"
                      placeholder="director@company.com"
                    />
                  </div>
                </div>

                <button 
                  type="submit" 
                  disabled={isSubmitting}
                  className={`w-full text-white font-bold py-4 rounded-xl transition-all duration-300 shadow-lg flex justify-center items-center text-lg mt-4 ${isSubmitting ? 'bg-gray-400 cursor-not-allowed' : 'bg-finOrange hover:bg-orange-600'}`}
                >
                  {isSubmitting ? (
                    <><Loader2 className="w-6 h-6 mr-2 animate-spin" /> Processing...</>
                  ) : (
                    <>Send Reset Link</>
                  )}
                </button>
              </form>
            </div>
          )}

          <div className="mt-12 pt-8 border-t border-gray-100 text-center">
            <p className="text-gray-600 text-sm">
              Not a client yet? <Link to="/contact" className="font-bold text-finBlue hover:text-finOrange transition-colors">Request Account Access</Link>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ClientPortal;